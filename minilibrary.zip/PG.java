import java.awt.*;
import java.awt.event.*;

public class PG extends Frame implements ActionListener,ItemListener
{
	Panel p,p1,p2,p3;
	Label l,l1[];
	Checkbox c1,c2;
	CheckboxGroup cg;
	CardLayout c=new CardLayout();
	Button b[];
	String s[]={"ME CAD/CAM","ME ECE","ME EEE","ME THERMAL","MTECH CSE","MTECH IT"},
		s1[]={"HOME","BORROW","PG"},
		s2[]={"MCADCAM_1stYear","MEECE_1stYear","MEEEE_1stYear","METHERMAL_1stYear","MCSE_1stYear","MTIT_1stYear"},
		s3[]={" ","MEECE_2ndYear","MEEEE_2ndYear","METHERMAL_2ndYear"," "," "};
		
	public PG()
	{
		setVisible(true);
		setSize(1500,1500);	
		setLayout(null);
		setTitle("Post Graduation");

		l=new Label("Post Graduation");
		l1=new Label[s1.length-1];
		
		p=new Panel(new GridLayout(s.length+1,1,30,30));
		p2=new Panel(new FlowLayout(FlowLayout.LEFT));
		p1=new Panel();

		l.setFont(new Font("TimesNewRoman",Font.BOLD,20));
		add(l);		
		l.setBounds(600,40,240,40);
		
		cg=new CheckboxGroup();
		b=new Button[s.length+s1.length];
		
		for(int i=0;i<s.length;i++)
		{
			b[i]=new Button(s[i]);
			p.add(b[i]);
		}
		p.setBounds(300,200,200,350);
		add(p);
		
		
		for(int i=0;i<s.length;i++)
		{
			b[i].addActionListener(this);
		}
		for(int i=0;i<l1.length;i++)
		{
			l1[i]=new Label(">");
		}

		for(int i=s.length,j=0;i<(s1.length+s.length) && j<s1.length;i++,j++)
		{
			b[i]=new Button(s1[j]);
			p2.add(b[i]);
			if(j<l1.length)
				p2.add(l1[j]);
			
			b[i].addActionListener(this);
		}
		add(p2);
		p2.setBounds(20,95,700,100);
		
		p1.setLayout(c);
		p1.setBounds(700,300,200,100);
		
		

		this.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		String str=ae.getActionCommand();
		if(str=="HOME")
		{
			new Home();
			this.dispose();
		}
		if(str=="BORROW")
		{
			new Borrow();
			this.dispose();
		}
		if(str=="PG")
		{
			new PG();
			this.dispose();
		}
		p3=new Panel();
		p3.setLayout(new GridLayout(2,0));
		for(int i=0;i<s.length;i++)
		{
			if(str==s[i])
			{
				
				c1=new Checkbox(s2[i],false,cg);
				p3.add(c1);
				if(i==1||i==2||i==3)
				{
					c2=new Checkbox(s3[i],false,cg);
					p3.add(c2);
					c2.addItemListener(this);

				}
				p1.add(p3,"a1");
				this.add(p1);
				c.show(p1,"a1");

				c1.addItemListener(this);
				
				setVisible(true);
				break;
			}
			
		}
	}
	public void itemStateChanged(ItemEvent ie)
	{
		String str1=cg.getSelectedCheckbox().getLabel();
		if(str1=="MCADCAM_1stYear")
		{
			new MCADCAM_1stYear();
			this.dispose();
		}
		else if(str1=="MEECE_1stYear")
		{
			new MEECE_1stYear();
			this.dispose();
		}		
		else if(str1=="MEECE_2ndYear")
		{
			new MEECE_2ndYear();
			this.dispose();
		}
		else if(str1=="MEEEE_1stYear")
		{
			new MEEEE_1stYear();
			this.dispose();
		}	
		else if(str1=="MEEEE_2ndYear")
		{
			new MEEEE_2ndYear();
			this.dispose();
		}
		else if(str1=="METHERMAL_1stYear")
		{
			new METHERMAL_1stYear();
			this.dispose();
		}
		else if(str1=="METHERMAL_2ndYear")
		{
			new METHERMAL_2ndYear();
			this.dispose();
		}			
		else if(str1=="MCSE_1stYear")
		{
			new MCSE_1stYear();
			this.dispose();
		}
		else if(str1=="MTIT_1stYear")
		{
			new MTIT_1stYear();
			this.dispose();
		}
			
	}
	public void paint(Graphics g)
	{

		g.drawRect(650,250,300,200);
		g.drawString("",770,270);
		

	}
	public static void main(String args[])
	{
		new PG();
	}
}
		