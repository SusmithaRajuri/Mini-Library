import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
public class Issue extends Frame implements ActionListener
{
	Label l[],l0[],l1[];
	String s,s1[]={"Issue","Name : ","Branch : ","Year : ","Rollnumber : ","Books Selected : "},s2;
	Panel p,p1;
	Button b,b1[],b2;
	BufferedReader f1;
	Scanner sc1;
	Login x;
	Biotech_1stYear st;
	File f;
	int ln=0;
	public Issue()
	{
		try
		{	
			setVisible(true);
			setSize(1500,1500);
			setLayout(null);
			setTitle("Issue");

			x=new Login();
			x.setVisible(false);

			st=new Biotech_1stYear();
			st.setVisible(false);

			
			l=new Label[6];
			l0=new Label[4];
			l0[0]=new Label(x.s1);
			l0[1]=new Label(x.s5);
			l0[2]=new Label(x.s6);
			l0[3]=new Label(x.s4);

		
			for(int i=0;i<l.length;i++)
				l[i]=new Label(s1[i]);
			l[0].setFont(new Font("TimesNewRoman",Font.BOLD,20));
			l[0].setBounds(600,50,150,30);
			add(l[0]);
		
			p=new Panel();

			p.setLayout(new GridLayout(5,1));
			for(int i=1;i<l.length;i++)
			{
				p.add(l[i]);
			
			}
			p.add(l[1]);
			p.add(l0[0]);
			p.add(l[2]);
			p.add(l0[1]);
			p.add(l[3]);
			p.add(l0[2]);
			p.add(l[4]);
			p.add(l0[3]);
			p.add(l[5]);
			add(p);
			p.setBounds(30,100,300,150);

			b=new Button("Submit");
			add(b);
			b.setBounds(650,600,50,30);
			b.addActionListener(this);

			l1=new Label[4];
			b1=new Button[4];
			f=new File(x.s1+"sample.txt");
			f1=new BufferedReader(new FileReader(f));
			
			sc1=new Scanner(f1);


			p1=new Panel();
			p1.setLayout(new FlowLayout(FlowLayout.LEFT));

			for(int i=0;sc1.hasNextLine();i++)
			{
				ln++;
				l1[i]=new Label(sc1.nextLine());
				p1.add(l1[i]);
				b1[i]=new Button("Cancel");
				p1.add(b1[i]);
				b1[i].addActionListener(this);	
			}
			p1.setBounds(30,300,600,300);
			add(p1);
			f1.close();
			
			
		}
		catch(Exception d)
		{
		}
		
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		s=ae.getActionCommand();
		b2=(Button)ae.getSource();
		if(b2==b)
		{
			try	
			{
				f.delete();
				this.dispose();
			}
			catch(Exception y)
			{
			}
		}
		else
		{
			for(int i=0;i<ln;i++)
			{
				if(b2==b1[i])
				{
					l1[i].setVisible(false);
					b1[i].setVisible(false);
					try
					{
						File f1=new File(x.s1+".txt");
						BufferedReader f2=new BufferedReader(new FileReader(f1));
						Scanner sc1=new Scanner(f2);
						File f3=new File(x.s1+"sample1.txt");
						BufferedWriter f4=new BufferedWriter(new FileWriter(f3,true));
						while(sc1.hasNextLine())
						{
							s2=sc1.nextLine();
							if(l1[i].getText().equals(s2))
							{
								if(sc1.hasNextLine())
								{
									f4.write(sc1.nextLine());
									f4.newLine();
								}
							}
							else
							{
								f4.write(s2);
								f4.newLine();
							}
						}
						f2.close();
						f4.close();
						f1.delete();	
						f3.renameTo(f1);	
					}
					catch(Exception g)
					{}
					break;
				}
			}
		}		
	}
	public void paint(Graphics g)
	{
	}	
	public static void main(String args[]) throws IOException
	{
		new Issue();
	}
}
