import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
public class Details extends Frame implements ActionListener
{
	Label l[],l0[],l1[];
	String s,s1[]={"MINI LIBRARY","Name:","Rollnumber:","Branch:","Year:","Books:"};
	Panel p1,p2;
	Button b1;
	Details()
	{
		try
		{
			setVisible(true);
			setSize(1500,1500);
			setLayout(null);
			setTitle("Details");

			l=new Label[6];
		
			for(int i=0;i<l.length;i++)
				l[i]=new Label(s1[i]);
			l[0].setFont(new Font("TimesNewRoman",Font.BOLD,24));
			l[0].setBounds(600,30,200,30);
			add(l[0]);
			
			b1=new Button("Home");
			b1.setBounds(50,120,50,30);
			add(b1);		

			Login x=new Login();
			x.setVisible(false);
		
			l0=new Label[4];
			l0[0]=new Label(x.s1);
			l0[1]=new Label(x.s4);
			l0[2]=new Label(x.s5);
			l0[3]=new Label(x.s6);
		
			p1=new Panel();
			p1.setLayout(new GridLayout(5,1));


			for(int i=1,j=0;i<l.length;i++,j++)
			{
				p1.add(l[i]);
				if(j<l0.length)
					p1.add(l0[j]);
			}
		
			add(p1);
			p1.setBounds(30,150,200,200);

			BufferedReader f1=new BufferedReader(new FileReader(x.s1+".txt"));
			Scanner sc=new Scanner(f1);
			p2=new Panel();
			p2.setLayout(new GridLayout(4,0));
			l1=new Label[4];			
			for(int i=0;i<l1.length&&sc.hasNextLine();i++)
			{
				l1[i]=new Label(sc.nextLine());
				p2.add(l1[i]);
			}

			add(p2);
			p2.setBounds(30,400,400,200);	
			
			b1.addActionListener(this);

			
		}
		catch(Exception e)
		{
		}
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		s=ae.getActionCommand();
		if(s=="Home")
		{
			new Home();
			this.dispose();
		}
	}
	public static void main(String args[])
	{
		new Details();
	}
}