import java.awt.*;
import java.awt.event.*;

public class Detail extends Frame implements ActionListener
{
	TextField t1,t2,t3,t4,t5;
	Label l1,l2,l3,l4,l5,l6;
	Button b1;
	String s;
	Detail()
	{	
		this.setLayout(null);
		setTitle("DETAIL PAGE");
		setSize(500,500);
		setVisible(true);
		
		l1=new Label("DETAILS ");
		l1.setBounds(550,0,90,160);
		l1.setFont(new Font("TimesNewRoman",Font.BOLD,20));		

		b1=new Button("Home");
		b1.setBounds(50,120,50,30);		

		l2=new Label("Name: ");
		l3=new Label("Roll no : ");
		l4=new Label("Books Issued: ");
		l5=new Label("Due : ");
		l6=new Label("Last Date : ");
		
		l2.setBounds(50,200,80,80);
		l3.setBounds(50,250,80,80);
		l4.setBounds(50,300,80,80);
		l5.setBounds(50,350,80,80);
		l6.setBounds(50,400,80,80);

		t1=new TextField(15);
		t2=new TextField(15);
		t3=new TextField(15);
		t4=new TextField(15);
		t5=new TextField(15);

		add(l1);
		add(l2);
		add(l3);
		add(l4);
		add(l5);
		add(l6);

		add(t1);
		add(t2);
		add(t3);
		add(t4);
		add(t5);

		add(b1);


		b1.addActionListener(this);	
		t1.addActionListener(this);
		t2.addActionListener(this);
		t3.addActionListener(this);
		t4.addActionListener(this);
		t5.addActionListener(this);
		
		
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});
	}
	public void actionPerformed(ActionEvent ae)
	{
		s=ae.getActionCommand();
		if(s=="Home");
		{
			new Home();
			this.dispose();
		}				
	}
	public static void main(String args[])
	{
		Detail f=new Detail();
	}
}
				