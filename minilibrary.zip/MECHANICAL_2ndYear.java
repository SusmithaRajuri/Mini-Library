import java.awt.*;
import java.awt.event.*;
public class MECHANICAL_2ndYear extends Frame implements ActionListener,ItemListener
{
	Label l1,l2,l3,l4,l5,l6;
	Panel p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16;
	CheckboxGroup cg1,cg2,cg3,cg4;
	Checkbox c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18;
	Button b1,b2,b3,b4,b5,b6;
	String s="";
	MECHANICAL_2ndYear()
	{
		setVisible(true);
		setSize(500,500);
		setLayout(null);
		setTitle("MINI LIBRARY");
		l1=new Label("MECHANICAL 2nd Year");
		l4=new Label(">");
		l5=new Label(">");
		l6=new Label(">");
		b3=new Button("Home");
		b4=new Button("Borrow");
		b5=new Button("UG");
		b6=new Button("MECHANICAL_2ndYear");
		l2=new Label("1st SEMESTER :");
		l3=new Label("2nd SEMESTER :");
		add(l1);
		add(b3);
		add(l4);
		add(b4);
		add(l5);
		add(b5);
		add(l6);
		add(b6);
		b3.setBounds(20,70,80,30);
		l4.setBounds(100,77,10,10);
		b4.setBounds(110,70,80,30);
		l5.setBounds(190,77,10,10);
		b5.setBounds(200,70,80,30);
		l6.setBounds(280,77,10,10);
		b6.setBounds(290,70,140,30);
		add(l2);
		add(l3);
		l1.setBounds(650,0,140,80);
		l2.setBounds(10,100,100,100);
		l3.setBounds(10,400,100,100);
		p1=new Panel();
		p2=new Panel();
		p3=new Panel();
		p4=new Panel();
		p5=new Panel();
		p6=new Panel();
		p7=new Panel();
		p8=new Panel();
		cg2=new CheckboxGroup();
		cg1=new CheckboxGroup();
		c1=new Checkbox("Fourier Analysis & Partial Differential Equations",false,cg1);
		c2=new Checkbox("Material Science & Metallurgy			    		              ",false,cg1);
		c3=new Checkbox("Machine Drawing                                                       ",false,cg1);
		c4=new Checkbox("Mechanics of Materials                                             ",false,cg1);
		c5=new Checkbox("Environmental Studies                                              ",false,cg1);
		c6=new Checkbox("Managerial Economics & Accountancy                   ",false,cg1);
		p1.add(c1);
		p1.add(c2);
		p1.add(c3);
		p1.add(c4);
		p1.add(c5);
		p1.add(c6);
		add(p1);
		p1.setBounds(30,200,300,250);
		c1.addItemListener(this);
		c2.addItemListener(this);
		c3.addItemListener(this);
		c4.addItemListener(this);
		c5.addItemListener(this);
		c6.addItemListener(this);




		p9=new Panel();
		p10=new Panel();
		p11=new Panel();
		p12=new Panel();
		p13=new Panel();
		p14=new Panel();
		p15=new Panel();
		p16=new Panel();
		cg4=new CheckboxGroup();
		cg3=new CheckboxGroup();
		c10=new Checkbox("Complex Variables and Probability Statistics",false,cg3);
		c11=new Checkbox("Kinematics of Machines                                     ",false,cg3);		
		c12=new Checkbox("Thermodynamics                                                ",false,cg3);
		c13=new Checkbox("Fluid Dynamics                                                    ",false,cg3);
		p9.add(c10);
		p9.add(c11);
		p9.add(c12);
		p9.add(c13);
		add(p9);
		p9.setBounds(20,500,300,250);
		c10.addItemListener(this);
		c11.addItemListener(this);
		c12.addItemListener(this);
		c13.addItemListener(this);



		b1=new Button("Done");
		b2=new Button("Next");
		add(b1);
		add(b2);
		b1.setBounds(500,700,50,30);
		b2.setBounds(900,700,50,30);
		b1.addActionListener(this);
		b2.addActionListener(this);
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});

	}
	public void actionPerformed(ActionEvent ae)
	{
	}
	public void itemStateChanged(ItemEvent ie)
	{
		s=((Checkbox)ie.getSource()).getLabel();
		if(s=="Fourier Analysis & Partial Differential Equations")
		{
			c8=new Checkbox("Kanti B Datta ",false,cg2);
			c9=new Checkbox("B.S.Grewal ",false,cg2);
			p2.add(c8);
			p2.add(c9);
			add(p2);
			p2.setBounds(300,200,350,350);
			this.setVisible(true);
		}
		else if(s=="Material Science & Metallurgy			    		              ")
		{
			c8=new Checkbox("V. Raghavan",false,cg2);
			c9=new Checkbox("S.H. Avner",false,cg2);
			p3.add(c8);
			p3.add(c9);
			add(p3);
			p3.setBounds(300,230,350,350);
			setVisible(true);	
		}
		else if(s=="Machine Drawing                                                       ")
		{
			c8=new Checkbox("N. Siddeshwar",false,cg2);
			c9=new Checkbox("N.D. Bhatt",false,cg2);
			p4.add(c8);
			p4.add(c9);
			add(p4);
			p4.setBounds(300,255,350,350);
			setVisible(true);
		}
		else if(s=="Mechanics of Materials                                             ")
		{
			c8=new Checkbox("D.S. Prakash Rao",false,cg2);
			c9=new Checkbox("S. Ramamrutham",false,cg2);
			p5.add(c8);
			p5.add(c9);
			add(p5);
			p5.setBounds(300,283,350,350);
			setVisible(true);
		}
		else if(s=="Environmental Studies                                              ")
		{
			c8=new Checkbox("Y. Anjaneyulu",false,cg2);
			c9=new Checkbox("S.S.Dara",false,cg2);
			p6.add(c8);
			p6.add(c9);
			add(p6);
			p6.setBounds(300,315,350,350);
			setVisible(true);
		}
		else if(s=="Managerial Economics & Accountancy                   ")
		{
			c8=new Checkbox("Mehta P.L",false,cg2);
			c9=new Checkbox("Maheswari S.N ",false,cg2);
			p7.add(c8);
			p7.add(c9);
			add(p7);
			p7.setBounds(300,338,350,350);
			setVisible(true);
		}
		else if(s=="Complex Variables and Probability Statistics")
		{
			c17=new Checkbox("KantiB.Datta ",false,cg4);
			c18=new Checkbox("Gupta and Kapoor ",false,cg4);
			p10.add(c17);
			p10.add(c18);
			add(p10);
			p10.setBounds(300,500,350,350);
			setVisible(true);	
		}
		else if(s=="Kinematics of Machines                                     ")
		{
			c17=new Checkbox("Thomas Bevan",false,cg4);
			c18=new Checkbox("S.S. Rattan",false,cg4);
			p11.add(c17);
			p11.add(c18);
			add(p11);
			p11.setBounds(300,530,350,350);
			setVisible(true);	
		}
		else if(s=="Thermodynamics                                                ")
		{
			c17=new Checkbox("P.K. Nag",false,cg4);
			c18=new Checkbox("D.S. Kumar",false,cg4);
			p12.add(c17);
			p12.add(c18);
			add(p12);
			p12.setBounds(300,555,350,350);
			setVisible(true);	
		}
		else if(s=="Fluid Dynamics                                                    ")
		{
			c17=new Checkbox("P.N.Modi and S.M.Seth",false,cg4);
			c18=new Checkbox("R.K.Rajput",false,cg4);
			p13.add(c17);
			p13.add(c18);
			add(p13);
			p13.setBounds(300,584,350,350);
			setVisible(true);	
		}
	}
	public void paint(Graphics g)
	{
		
	}
	public static void main(String args[])
	{
		new MECHANICAL_2ndYear();
	}
}	
		