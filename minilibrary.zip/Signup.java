import java.awt.*;
import java.awt.event.*;
import java.io.*;
public class Signup extends Frame implements ActionListener,ItemListener 
{
	TextField t[];
	Choice c[];
	Button b1;
	Panel p1,p2;
	Label l[],l1;
	String s1[]={"Name","Roll No","E-mail ID","Mobile No.","Password","Branch","Year","Date Of Birth","Gender"},
	       s2[]={"BIO-TECH","CHEMICAL","CIVIL","CSE","ECE","EEE","IT","MCA","MECH","ME CAD/CAM","ME ECE","ME THERMAL","MTECH CSE","MTECH IT","PROD"},
	       s3[]={"January","February","March","April","May","June","July","August","September","October","November","December"},
	       s4[]={"Female","Male"},s;

	
	Choice ch;

	BufferedWriter f1=new BufferedWriter(new FileWriter("Username.txt",true));
	BufferedWriter f2=new BufferedWriter(new FileWriter("Rollnumber.txt",true));
	BufferedWriter f3=new BufferedWriter(new FileWriter("Email.txt",true));
	BufferedWriter f4=new BufferedWriter(new FileWriter("Mobilenumber.txt",true));
	BufferedWriter f5=new BufferedWriter(new FileWriter("Password.txt",true));
	BufferedWriter f6=new BufferedWriter(new FileWriter("Branch.txt",true));
	BufferedWriter f7=new BufferedWriter(new FileWriter("Year.txt",true));
	BufferedWriter f8=new BufferedWriter(new FileWriter("Date of birth.txt",true));
	BufferedWriter f9=new BufferedWriter(new FileWriter("Gender.txt",true));

	


	public Signup() throws IOException
	{
		setVisible(true);
		setSize(1500,1500);
		setLayout(null);
		setTitle("Signup");

		l1=new Label("MINI LIBRARY");
		l1.setFont(new Font("TimesNewRoman",Font.BOLD,20));
		add(l1);
		l1.setBounds(600,20,150,40);

		l=new Label[9];
		for(int i=0;i<s1.length;i++)
			l[i]=new Label(s1[i]);
		t=new TextField[5];
		for(int i=0;i<5;i++)
			t[i]=new TextField(50);
		p1=new Panel();
		
		p1.setLayout(new GridLayout(10,1));
		for(int i=0;i<5;i++)
		{
			p1.add(l[i]);
			p1.add(t[i]);
		}
		t[4].setEchoChar('*');
		c=new Choice[6];
		for(int i=0;i<6;i++)
			c[i]=new Choice();
		c[0].add(" ");
		c[1].add(" ");
		c[2].add(" ");
		c[3].add(" ");
		c[4].add(" ");
		c[5].add(" ");
		for(int i=0;i<s2.length;i++)
			c[0].add(s2[i]);
		for(int i=1;i<=3;i++)
			c[1].add(Integer.toString(i));
		
		for(int i=1;i<=31;i++)
			c[2].add(Integer.toString(i));//date
		
		for(int i=0;i<s3.length;i++)
			c[3].add(s3[i]);//month
		
		for(int i=1980;i<=2016;i++)
			c[4].add(Integer.toString(i));//year
		
		for(int i=0;i<s4.length;i++)
			c[5].add(s4[i]);

		p2=new Panel();
		p2.setLayout(new FlowLayout(FlowLayout.LEFT));
		for(int i=2;i<=4;i++)
			p2.add(c[i]);
			
		p1.add(l[5]);
		p1.add(c[0]);
		p1.add(l[6]);
		p1.add(c[1]);
		p1.add(l[7]);
		p1.add(p2);
		p1.add(l[8]);
		p1.add(c[5]);
		
		add(p1);
		p1.setBounds(380,150,600,500);
		

		b1=new Button("Submit");
		add(b1);
		b1.setBounds(650,650,50,30);


		b1.addActionListener(this);
		for(int i=0;i<6;i++)
		{
			c[i].addItemListener(this);
		}



		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});

	}
	public void actionPerformed(ActionEvent ae)
	{
		s=ae.getActionCommand();
		try
		{
		
				f1.write(t[0].getText());
				f1.newLine();
				f1.close();
			
				
				f2.write(t[1].getText());
				f2.newLine();
				f2.close();

				
				f3.write(t[2].getText());
				f3.newLine();
				f3.close();

				
				f4.write(t[3].getText());
				f4.newLine();
				f4.close();
	
				
				f5.write(t[4].getText());
				f5.newLine();
				f5.close();
		}
		catch(IOException ie)
		{
		}
		if(s=="Submit")
		{
			try
			{
				new Login();
				this.dispose();
			}
			catch(Exception r)
			{}
		}
		
	}
	public void itemStateChanged(ItemEvent ie)
	{

		ch=(Choice)ie.getSource();
		try
		{
			if(ch==c[0])
			{
				
				f6.write(c[0].getSelectedItem());
				f6.newLine();
				f6.close();
			}
			else if(ch==c[1])
			{
				
				f7.write(c[1].getSelectedItem());
				f7.newLine();
				f7.close();
			}
			else if(ch==c[2])
			{	
				f8.write(c[2].getSelectedItem());
			}
			else if(ch==c[3])
			{
				f8.write(" "+c[3].getSelectedItem());
			}
			else if(ch==c[4])
			{
				f8.write(" "+c[4].getSelectedItem());
				f8.newLine();
				f8.close();
			}
			else if(ch==c[5])
			{
				f9.write(c[5].getSelectedItem());
				f9.newLine();
				f9.close();
			}
		}
		catch(IOException i)
		{
		}
	}
	public void paint(Graphics g)
	{
		g.drawRect(330,100,700,600);
	}
	public static void main(String args[]) throws IOException
	{
		new Signup();
	}
}
		