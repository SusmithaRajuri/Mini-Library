import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
public class Return extends Frame implements ActionListener
{
	Label l[],l0[],l1[];
	String s1[]={"MINI LIBRARY","Name:","Rollnumber:","Branch:","Year:","Books:"},s2;
	Panel p1,p2;
	int count=0;
	Button b1[],b2,b3;
	Login x;
	Return()
	{
		try
		{
			setVisible(true);
			setSize(1500,1500);
			setLayout(null);
			setTitle("Return");

			l=new Label[6];
		
			for(int i=0;i<l.length;i++)
				l[i]=new Label(s1[i]);
			l[0].setFont(new Font("TimesNewRoman",Font.BOLD,24));
			l[0].setBounds(600,30,200,30);
			add(l[0]);
		
			Login x=new Login();
			x.setVisible(false);
		
			l0=new Label[4];
			l0[0]=new Label(x.s1);
			l0[1]=new Label(x.s4);
			l0[2]=new Label(x.s5);
			l0[3]=new Label(x.s6);
		
			p1=new Panel();
			p1.setLayout(new GridLayout(5,1));


			for(int i=1,j=0;i<l.length;i++,j++)
			{
				p1.add(l[i]);
				if(j<l0.length)
					p1.add(l0[j]);
			}
		
			add(p1);
			p1.setBounds(30,150,200,200);

			BufferedReader f1=new BufferedReader(new FileReader(x.s1+".txt"));
			Scanner sc=new Scanner(f1);
			p2=new Panel();
			
			l1=new Label[4];			
			for(int i=0;i<l1.length&&sc.hasNextLine();i++)
			{
				l1[i]=new Label(sc.nextLine());
				count++;
			}
			b1=new Button[count];
			for(int i=0;i<count;i++)
			{
				b1[i]=new Button("Return");
				p2.add(l1[i]);
				p2.add(b1[i]);
				b1[i].addActionListener(this);
			}
			p2.setLayout(new GridLayout(count,1));
			add(p2);
			p2.setBounds(30,360,1200,100);
			f1.close();
			try
			{
				x=new Login();
				x.setVisible(false);
			}
			catch(Exception g)
			{}
				
			b3=new Button("Home");
			b3.setBounds(30,100,60,40);
			add(b3);
			b3.addActionListener(this);

			
		}
		catch(Exception e)
		{
		}
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		b2=(Button)ae.getSource();
		for(int i=0;i<count;i++)
		{
			if(b2==b1[i])
			{
				l1[i].setVisible(false);
				b1[i].setVisible(false);
				try
				{
					File f1=new File(x.s1+".txt");
					BufferedReader f2=new BufferedReader(new FileReader(f1));
					Scanner sc1=new Scanner(f2);


					File f3=new File(x.s1+"sample.txt");
					BufferedWriter f4=new BufferedWriter(new FileWriter(f3,true));
					
					while(sc1.hasNextLine())
					{
						s2=sc1.nextLine();
						if(l1[i].getText().equals(s2))
						{
							if(sc1.hasNextLine())
							{
								f4.write(sc1.nextLine());
								f4.newLine();
							}
						}
						else
						{
							f4.write(s2);
							f4.newLine();
						}
					}

					f2.close();
					f4.close();
					f1.delete();	
					f3.renameTo(f1);	
								
				}
				catch(Exception g)
				{}
				break;
			}
		}
		if(b2==b3)
		{
			new Home();
			this.dispose();
		}
	}
	public static void main(String args[])
	{
		new Return();
	}
}