import java.awt.*;
import java.awt.event.*;
/*<html>
<applet code="Test.java" width=700 height=900>
</applet>
</html>*/
public class Test extends Frame implements ActionListener
{
	Panel p,p1,p2,p3,p4,p5,p6,p7,p8;
	Label l,l1,l2;
	Checkbox c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16;
	CheckboxGroup cg,cg1,cg2,cg3,cg4,cg5,cg6,cg7;
	Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b10,b11;
	public Test()
	{
		setVisible(true);
		setSize(600,900);	
		setLayout(null);
		l=new Label("PG");
		l1=new Label(">");
		l2=new Label(">");
		

		b1=new Button("M TECH CSE");
		b2=new Button("M TECH IT");
		b3=new Button("ME CAD/CAM");
		b4=new Button("ME THERMAL ENG");
		b5=new Button("ME ECE");
		b6=new Button("ME EEE");
		b7=new Button("MCA");
		b8=new Button("MBA");
		b9=new Button("HOME");
		b10=new Button("BORROW");
		b11=new Button("PG");
		
		
		cg=new CheckboxGroup();
		c1=new Checkbox("1 st year",false,cg);
		c2=new Checkbox("2 nd year",false,cg);
		cg1=new CheckboxGroup();
		c3=new Checkbox("1 st year",false,cg1);
		c4=new Checkbox("2 nd year",false,cg1);
		cg2=new CheckboxGroup();
		c5=new Checkbox("1 st year",false,cg2);
		c6=new Checkbox("2 nd year",false,cg2);
		cg3=new CheckboxGroup();
		c7=new Checkbox("1 st year",false,cg3);
		c8=new Checkbox("2 nd year",false,cg3);
		cg4=new CheckboxGroup();
		c9=new Checkbox("1 st year",false,cg4);
		c10=new Checkbox("2 nd year",false,cg4);
		cg5=new CheckboxGroup();
		c11=new Checkbox("1 st year",false,cg5);
		c12=new Checkbox("2 nd year",false,cg5);
		cg6=new CheckboxGroup();
		c13=new Checkbox("1 st year",false,cg6);
		c14=new Checkbox("2 nd year",false,cg6);
		cg7=new CheckboxGroup();
		c15=new Checkbox("1 st year",false,cg7);
		c16=new Checkbox("2 nd year",false,cg7);

		add(l);
		add(b1);
		add(b2);
		add(b3);
		add(b4);
		add(b5);
		add(b6);
		add(b7);
		add(b8);

		l.setBounds(400,50,60,40);
		b1.setBounds(370,120,80,20);
		b2.setBounds(370,190,80,20);
		b3.setBounds(370,260,80,20);
		b4.setBounds(370,330,110,20);
		b5.setBounds(370,400,80,20);
		b6.setBounds(370,470,80,20);
		b7.setBounds(370,540,80,20);
		b8.setBounds(370,610,80,20);

		p=new Panel();
		p1=new Panel();
		p2=new Panel();
		p3=new Panel();
		p4=new Panel();
		p5=new Panel();
		p6=new Panel();
		p7=new Panel();
		p8=new Panel();

		p8.add(b9);
		p8.add(l1);
		p8.add(b10);
		p8.add(l2);
		p8.add(b11);
		p8.setBounds(0,30,290,30);
		add(p8);

		p.setBounds(370,140,300,50);
		p.add(c1);
		p.add(c2);

		p1.setBounds(370,210,300,50);
		p1.add(c3);
		p1.add(c4);

		p2.setBounds(370,280,300,50);
		p2.add(c5);
		p2.add(c6);
		
		p3.setBounds(370,350,300,50);
		p3.add(c7);
		p3.add(c8);

		p4.setBounds(370,420,300,50);
		p4.add(c9);
		p4.add(c10);

		p5.setBounds(370,490,300,50);
		p5.add(c11);
		p5.add(c12);

		p6.setBounds(370,580,300,50);
		p6.add(c13);
		p6.add(c14);
	
		p7.setBounds(370,650,300,50);
		p7.add(c15);
		p7.add(c16);
		
		

		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);
		b7.addActionListener(this);
		b8.addActionListener(this);
		
		this.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		
		
	}
	public void actionPerformed(ActionEvent ae)
	{
		String str=ae.getActionCommand();
		if(str.equals("M TECH CSE"))
		{
		this.add(p);
		setVisible(true);
		}
		if(str.equals("M TECH IT"))
		{
		this.add(p1);
		setVisible(true);
		}
		if(str.equals("ME CAD/CAM"))
		{
		this.add(p2);
		setVisible(true);
		}
		if(str.equals("ME THERMAL ENG"))
		{
		this.add(p3);
		setVisible(true);
		}
		if(str.equals("ME ECE"))
		{
		this.add(p4);
		setVisible(true);
		}
		if(str.equals("ME EEE"))
		{
		this.add(p5);
		setVisible(true);
		}
		if(str.equals("MCA"))
		{
		this.add(p6);
		setVisible(true);
		}
		if(str.equals("MBA"))
		{
		this.add(p7);
		setVisible(true);
		}
	}
	public static void main(String args[])
	{
		new Test();
	}
}
		