import java.awt.*;
import java.awt.event.*;
/*<html>
<applet code="SignupPage.java" width=700 height=900>
</applet>
</html> */

public class SignupPage extends Frame 
{
	Button b1;
	TextField tf1,tf2,tf3,tf4,tf5,tf6,tf7,tf8;
	Checkbox c1;
	Label l1,l2,l3,l4,l5,l6,l7,l8,l9;
	public SignupPage()
	{
		setVisible(true);
		setSize(600,900);
		setLayout(null);
		l9=new Label("SIGN UP");
		l1=new Label("NAME");
		l2=new Label("ROLL NUMBER");
		l3=new Label("E-MAIL ID");
		l4=new Label("MOBILE NUMBER");
		l5=new Label("YEAR");
		l6=new Label("BRANCH");
		l7=new Label("DATE OF BIRTH");
		l8=new Label("GENDER");
		c1=new Checkbox("Agree terms and conditions");
		b1=new Button("Submit");
		tf1=new TextField(50);
		tf2=new TextField(50);
		tf3=new TextField(50);
		tf4=new TextField(50);
		tf5=new TextField(50);
		tf6=new TextField(50);
		tf7=new TextField(50);
		tf8=new TextField(50);

		add(l9);
		add(l1);
		add(tf1);
		add(l2);
		add(tf2);
		add(l3);
		add(tf3);
		add(l4);
		add(tf4);
		add(l5);
		add(tf5);
		add(l6);
		add(tf6);
		add(l7);
		add(tf7);
		add(l8);
		add(tf8);
		add(c1);
		add(b1);

		l9.setBounds(650,20,80,80);
		l1.setBounds(100,150,100,50);
		tf1.setBounds(250,150,150,30);
		l2.setBounds(100,200,100,50);
		l3.setBounds(100,250,100,50);
		l4.setBounds(100,300,100,50);
		l5.setBounds(100,350,100,50);
		l6.setBounds(100,400,100,50);
		l7.setBounds(100,450,100,50);
		l8.setBounds(100,500,100,50);
		tf2.setBounds(250,200,150,30);
		tf3.setBounds(250,250,150,30);
		tf4.setBounds(250,300,150,30);
		tf5.setBounds(250,350,150,30);
		tf6.setBounds(250,400,150,30);
		tf7.setBounds(250,450,150,30);
		tf8.setBounds(250,500,150,30);
		c1.setBounds(100,600,200,50);
		b1.setBounds(650,650,50,30);




		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});

	}

	public static void main(String args[])
	{
		new SignupPage();
	}
}




