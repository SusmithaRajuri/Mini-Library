import java.awt.*;
import java.awt.event.*;
public class IT_2ndYear extends Frame implements ActionListener,ItemListener
{
	Label l1,l2,l3;
	Panel p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16;
	CheckboxGroup cg1,cg2,cg3,cg4,cg5;
	Checkbox c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18;
	Button b1,b2;
	String s="";
	IT_2ndYear()
	{
		setVisible(true);
		setSize(500,500);
		setLayout(null);
		l1=new Label("IT 2nd YEAR");
		l2=new Label("1st SEMESTER :");
		l3=new Label("2nd SEMESTER :");
		add(l1);
		add(l2);
		add(l3);
		l1.setBounds(650,0,80,80);
		l2.setBounds(10,100,100,100);
		l3.setBounds(10,400,100,100);
		p1=new Panel();
		p2=new Panel();
		p3=new Panel();
		p4=new Panel();
		p5=new Panel();
		p6=new Panel();
		p7=new Panel();
		p8=new Panel();
		cg2=new CheckboxGroup();
		cg1=new CheckboxGroup();
		c1=new Checkbox("Discrete Structures ",false,cg1);
		c2=new Checkbox("Data Structures",false,cg1);
		c3=new Checkbox("Digital Electronics & Logic Design",false,cg1);
		c4=new Checkbox("Data Communications",false,cg1);
		c5=new Checkbox("Basic Electronics",false,cg1);
		c6=new Checkbox("Managerial Economics & Accountancy",false,cg1);
		
		p1.add(c1);
		p1.add(c2);
		p1.add(c3);
		p1.add(c4);
		p1.add(c5);
		p1.add(c6);
		
		add(p1);
		p1.setBounds(20,200,250,250);
		c1.addItemListener(this);
		c2.addItemListener(this);
		c3.addItemListener(this);
		c4.addItemListener(this);
		c5.addItemListener(this);
		c6.addItemListener(this);
		




		p9=new Panel();
		p10=new Panel();
		p11=new Panel();
		p12=new Panel();
		p13=new Panel();
		p14=new Panel();
		p15=new Panel();
		p16=new Panel();
		cg4=new CheckboxGroup();
		cg3=new CheckboxGroup();
		
		c10=new Checkbox("Probability and Random Processes",false,cg3);
		c11=new Checkbox("Java Programming",false,cg3);		
		c12=new Checkbox("Design and Analysis of Algorithms",false,cg3);
		c13=new Checkbox("Theory of Automata",false,cg3);
		c14=new Checkbox("Software Engineering",false,cg3);
		c15=new Checkbox("ComputerOrganization & Microprocessors",false,cg3);
		
		p9.add(c10);
		p9.add(c11);
		p9.add(c12);
		p9.add(c13);
		p9.add(c14);
		p9.add(c15);
		
		add(p9);
		p9.setBounds(30,500,260,250);
		c10.addItemListener(this);
		c11.addItemListener(this);
		c12.addItemListener(this);
		c13.addItemListener(this);
		c14.addItemListener(this);
		c15.addItemListener(this);
		



		b1=new Button("Done");
		b2=new Button("Next");
		add(b1);
		add(b2);
		b1.setBounds(500,700,50,30);
		b2.setBounds(900,700,50,30);
		b1.addActionListener(this);
		b2.addActionListener(this);
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});

	}
	public void actionPerformed(ActionEvent ae)
	{
	}
	public void itemStateChanged(ItemEvent ie)
	{
		s=((Checkbox)ie.getSource()).getLabel();
		
		if(s=="Discrete Structures")
		{
			c8=new Checkbox("Kenneth H Rosen",false,cg2);
			c9=new Checkbox("J. K. Sharma",false,cg2);
			p2.add(c8);
			p2.add(c9);
			add(p2);
			p2.setBounds(300,200,350,350);
			this.setVisible(true);
		}
		if(s=="Data Structures")
		{
			c8=new Checkbox("Michael T. Goodrich",false,cg2);
			c9=new Checkbox("Ellis Horowitz",false,cg2);
			p3.add(c8);
			p3.add(c9);
			add(p3);
			p3.setBounds(300,230,350,350);
			setVisible(true);	
		}
		if(s=="Digital Electronics & Logic Design")
		{
			c8=new Checkbox("Stephen Brown",false,cg2);
			c9=new Checkbox("Jain R.P",false,cg2);
			p4.add(c8);
			p4.add(c9);
			add(p4);
			p4.setBounds(300,255,350,350);
			setVisible(true);
		}
		if(s=="Data Communications")
		{
			c8=new Checkbox("Behrouz A. Forouzan",false,cg2);
			c9=new Checkbox("William Stallings",false,cg2);
			p5.add(c8);
			p5.add(c9);
			add(p5);
			p5.setBounds(300,283,350,350);
			setVisible(true);
		}
		if(s=="Basic Electronics")
		{
			c8=new Checkbox("Robert L. Boylestad",false,cg2);
			c9=new Checkbox("Morris Mano",false,cg2);
			p6.add(c8);
			p6.add(c9);
			add(p6);
			p6.setBounds(300,315,350,350);
			setVisible(true);
		}
		
		if(s=="Managerial Economics & Accountancy")
		{
			c8=new Checkbox(" Mehta P.L",false,cg2);
			c9=new Checkbox(" Maheswari S.N",false,cg2);
			p8.add(c8);
			p8.add(c9);
			add(p8);
			p8.setBounds(300,385,350,350);
			setVisible(true);
		}
		
		
		if(s=="Probability and Random Processes")
		{
			c17=new Checkbox("T.Veerarajan",false,cg4);
			c18=new Checkbox("P.Ramesh Babu",false,cg4);
			p10.add(c17);
			p10.add(c18);
			add(p10);
			p10.setBounds(300,500,350,350);
			setVisible(true);	
		}
		if(s=="Java Programming")
		{
			c17=new Checkbox("Herbert Schildt",false,cg4);
			c18=new Checkbox("Cay S. Horstmann",false,cg4);
			p11.add(c17);
			p11.add(c18);
			add(p11);
			p11.setBounds(300,530,350,350);
			setVisible(true);	
		}
		if(s=="Design and Analysis of Algorithms")
		{
			c17=new Checkbox("Ellis Horowitz",false,cg4);
			c18=new Checkbox("Thomas H. Cormen",false,cg4);
			p12.add(c17);
			p12.add(c18);
			add(p12);
			p12.setBounds(300,555,350,350);
			setVisible(true);	
		}
		if(s=="Theory of Automata")
		{
			c17=new Checkbox("John E. Hopcroft",false,cg4);
			c18=new Checkbox("John C Martin",false,cg4);
			p13.add(c17);
			p13.add(c18);
			add(p13);
			p13.setBounds(300,584,350,350);
			setVisible(true);	
		}
		if(s=="Software Engineering")
		{
			c17=new Checkbox("Roger S.Pressman",false,cg4);
			c18=new Checkbox("Carlo Ghezzi",false,cg4);
			p14.add(c17);
			p14.add(c18);
			add(p14);
			p14.setBounds(300,610,350,350);
			setVisible(true);	
		}
		if(s=="ComputerOrganization & Microprocessors")
		{
			c17=new Checkbox("Carl Hamacher",false,cg4);
			c18=new Checkbox("Ramesh S Gaonkar",false,cg4);
			p15.add(c17);
			p15.add(c18);
			add(p15);
			p15.setBounds(300,640,350,350);
			setVisible(true);
		}
		
		
	}
	public void paint(Graphics g)
	{
		
	}
	public static void main(String args[])
	{
		new IT_2ndYear();
	}
}	
		