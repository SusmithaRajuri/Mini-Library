import java.awt.*;
import java.awt.event.*;
public class MECHANICAL_1stYear extends Frame implements ActionListener,ItemListener
{
	Label l1,l2,l3,l4,l5,l6;
	Panel p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16;
	CheckboxGroup cg1,cg2,cg3,cg4;
	Checkbox c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18;
	Button b1,b2,b3,b4,b5,b6;
	String s="";
	MECHANICAL_1stYear()
	{
		setVisible(true);
		setSize(500,500);
		setLayout(null);
		setTitle("MINI LIBRARY");
		l1=new Label("MECHANICAL 1st Year");
		l4=new Label(">");
		l5=new Label(">");
		l6=new Label(">");
		b3=new Button("Home");
		b4=new Button("Borrow");
		b5=new Button("UG");
		b6=new Button("MECHANICAL_1stYear");
		l2=new Label("1st SEMESTER :");
		l3=new Label("2nd SEMESTER :");
		add(l1);
		add(b3);
		add(l4);
		add(b4);
		add(l5);
		add(b5);
		add(l6);
		add(b6);
		b3.setBounds(20,70,80,30);
		l4.setBounds(100,77,10,10);
		b4.setBounds(110,70,80,30);
		l5.setBounds(190,77,10,10);
		b5.setBounds(200,70,80,30);
		l6.setBounds(280,77,10,10);
		b6.setBounds(290,70,130,30);
		add(l2);
		add(l3);
		l1.setBounds(650,0,130,80);
		l2.setBounds(10,100,100,100);
		l3.setBounds(10,400,100,100);
		p1=new Panel();
		p2=new Panel();
		p3=new Panel();
		p4=new Panel();
		p5=new Panel();
		p6=new Panel();
		p7=new Panel();
		p8=new Panel();
		cg2=new CheckboxGroup();
		cg1=new CheckboxGroup();
		c1=new Checkbox("English - I                                             ",false,cg1);
		c2=new Checkbox("Mathematics - I                                     ",false,cg1);
		c3=new Checkbox("Engineering Physics - I                       ",false,cg1);
		c4=new Checkbox("Engineering Chemistry - I                   ",false,cg1);
		c5=new Checkbox("Structured Programming                     ",false,cg1);
		c6=new Checkbox("Engineering Mechanics - I                   ",false,cg1);
		c7=new Checkbox("Engineering Graphics-I                         ",false,cg1);
		p1.add(c1);
		p1.add(c2);
		p1.add(c3);
		p1.add(c4);
		p1.add(c5);
		p1.add(c6);
		p1.add(c7);
		add(p1);
		p1.setBounds(20,200,250,250);
		c1.addItemListener(this);
		c2.addItemListener(this);
		c3.addItemListener(this);
		c4.addItemListener(this);
		c5.addItemListener(this);
		c6.addItemListener(this);
		c7.addItemListener(this);




		p9=new Panel();
		p10=new Panel();
		p11=new Panel();
		p12=new Panel();
		p13=new Panel();
		p14=new Panel();
		p15=new Panel();
		p16=new Panel();
		cg4=new CheckboxGroup();
		cg3=new CheckboxGroup();
		c10=new Checkbox("English - II                                                         ",false,cg3);
		c11=new Checkbox("Mathematics - II                                                ",false,cg3);		
		c12=new Checkbox("Applied Physics                                                 ",false,cg3);
		c13=new Checkbox("Engineering Chemistry - II                               ",false,cg3);
		c14=new Checkbox("Object Oriented Programming through C++ ",false,cg3);
		c15=new Checkbox("Engineering Mechanics-II                                 ",false,cg3);
		c16=new Checkbox("Engineering Graphics-II                                    ",false,cg3);
		p9.add(c10);
		p9.add(c11);
		p9.add(c12);
		p9.add(c13);
		p9.add(c14);
		p9.add(c15);
		p9.add(c16);
		add(p9);
		p9.setBounds(30,500,260,250);
		c10.addItemListener(this);
		c11.addItemListener(this);
		c12.addItemListener(this);
		c13.addItemListener(this);
		c14.addItemListener(this);
		c15.addItemListener(this);
		c16.addItemListener(this);



		b1=new Button("Done");
		b2=new Button("Next");
		add(b1);
		add(b2);
		b1.setBounds(500,700,50,30);
		b2.setBounds(900,700,50,30);
		b1.addActionListener(this);
		b2.addActionListener(this);
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});

	}
	public void actionPerformed(ActionEvent ae)
	{
	}
	public void itemStateChanged(ItemEvent ie)
	{
		s=((Checkbox)ie.getSource()).getLabel();
		if(s=="English - I                                             ")
		{
			c8=new Checkbox("E Suresh Kumar          ",false,cg2);
			c9=new Checkbox("Michael McCarthy        ",false,cg2);
			p2.add(c8);
			p2.add(c9);
			add(p2);
			p2.setBounds(300,200,350,350);
			this.setVisible(true);
		}
		else if(s=="Mathematics - I                                     ")
		{
			c8=new Checkbox("Kanti.B.Datta           ",false,cg2);
			c9=new Checkbox("Michael Greenburg       ",false,cg2);
			p3.add(c8);
			p3.add(c9);
			add(p3);
			p3.setBounds(300,230,350,350);
			setVisible(true);	
		}
		else if(s=="Engineering Physics - I                       ")
		{
			c8=new Checkbox("M.N. Avadhanulu         ",false,cg2);
			c9=new Checkbox("S.L. Gupta              ",false,cg2);
			p4.add(c8);
			p4.add(c9);
			add(p4);
			p4.setBounds(300,255,350,350);
			setVisible(true);
		}
		else if(s=="Engineering Chemistry - I                   ")
		{
			c8=new Checkbox("P.C.Jain and Monica Jain",false,cg2);
			c9=new Checkbox("Puri & Sharma           ",false,cg2);
			p5.add(c8);
			p5.add(c9);
			add(p5);
			p5.setBounds(300,283,350,350);
			setVisible(true);
		}
		else if(s=="Structured Programming                     ")
		{
			c8=new Checkbox("PradipDey and ManasGhosh",false,cg2);
			c9=new Checkbox("R S Bichkar ",false,cg2);
			p6.add(c8);
			p6.add(c9);
			add(p6);
			p6.setBounds(300,315,350,350);
			setVisible(true);
		}
		else if(s=="Engineering Mechanics - I                   ")
		{
			c8=new Checkbox("K. Vijay Kumar Reddy    ",false,cg2);
			c9=new Checkbox("Ferdinand L Singer      ",false,cg2);
			p7.add(c8);
			p7.add(c9);
			add(p7);
			p7.setBounds(300,338,350,350);
			setVisible(true);
		}
		else if(s=="Engineering Graphics-I                         ")
		{
			c8=new Checkbox(" N.D.Bhatt",false,cg2);
			c9=new Checkbox("Basanth Agrawal and C M Agrawal ",false,cg2);
			p8.add(c8);
			p8.add(c9);
			add(p8);
			p8.setBounds(300,365,350,350);
			setVisible(true);
		}
		else if(s=="English - II                                                         ")
		{
			c17=new Checkbox("E Suresh Kumar          ",false,cg4);
			c18=new Checkbox("Michael McCarthy        ",false,cg4);
			p10.add(c17);
			p10.add(c18);
			add(p10);
			p10.setBounds(300,500,350,350);
			setVisible(true);	
		}
		else if(s=="Mathematics - II                                                ")
		{
			c17=new Checkbox("BS. Grewal              ",false,cg4);
			c18=new Checkbox("Michael Greenburg       ",false,cg4);
			p11.add(c17);
			p11.add(c18);
			add(p11);
			p11.setBounds(300,530,350,350);
			setVisible(true);	
		}
		else if(s=="Applied Physics                                                 ")
		{
			c17=new Checkbox("M.N. Avadhanulu         ",false,cg4);
			c18=new Checkbox("S.L. Gupta              ",false,cg4);
			p12.add(c17);
			p12.add(c18);
			add(p12);
			p12.setBounds(300,555,350,350);
			setVisible(true);	
		}
		else if(s=="Engineering Chemistry - II                               ")
		{
			c17=new Checkbox("Jain and Jain           ",false,cg4);
			c18=new Checkbox("Puri & Sharma           ",false,cg4);
			p13.add(c17);
			p13.add(c18);
			add(p13);
			p13.setBounds(300,584,350,350);
			setVisible(true);	
		}
		else if(s=="Object Oriented Programming through C++ ")
		{
			c17=new Checkbox("E. Balagurusamy         ",false,cg4);
			c18=new Checkbox("Bjarne Stroustrup       ",false,cg4);
			p14.add(c17);
			p14.add(c18);
			add(p14);
			p14.setBounds(300,610,350,350);
			setVisible(true);	
		}
		else if(s=="Engineering Mechanics-II                                 ")
		{
			c17=new Checkbox("K. Vijay Kumar Reddy and J. Suresh Kumar",false,cg4);
			c18=new Checkbox("Ferdinand L Singer",false,cg4);
			p15.add(c17);
			p15.add(c18);
			add(p15);
			p15.setBounds(300,640,350,350);
			setVisible(true);
		}
		else if(s=="Engineering Graphics-II                                    ")
		{
			c17=new Checkbox("N.D.Bhatt               ",false,cg4);
			c18=new Checkbox("Basanth Agrawal         ",false,cg4);
			p16.add(c17);
			p16.add(c18);
			add(p16);
			p16.setBounds(300,668,350,350);
			setVisible(true);
		}
	}
	public void paint(Graphics g)
	{
		
	}
	public static void main(String args[])
	{
		new MECHANICAL_1stYear();
	}
}	
		