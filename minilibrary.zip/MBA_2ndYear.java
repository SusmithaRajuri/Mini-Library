import java.awt.*;
import java.awt.event.*;
public class MBA_2ndYear extends Frame implements ActionListener,ItemListener
{
	Label l1,l2,l3,l4,l5;
	Panel p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,p12,p13,p14,p15,p16;
	CheckboxGroup cg1,cg2,cg3,cg4;
	Checkbox c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18;
	Button b1,b2,b3,b4,b5,b6;
	String s="";
	MBA_2ndYear()
	{
		setVisible(true);
		setSize(500,500);
		setLayout(null);
		setTitle("MINI LIBRARY");
		l1=new Label("MBA 2nd Year");
		l3=new Label(">");
		l4=new Label(">");
		l5=new Label(">");
		b3=new Button("Home");
		b4=new Button("Borrow");
		b5=new Button("UG");
		b6=new Button("MBA_2ndYear");
		l2=new Label("1st SEMESTER :");
		add(l1);
		add(b3);
		add(l3);
		add(b4);
		add(l4);
		add(b5);
		add(l5);
		add(b6);
		b3.setBounds(20,70,80,30);
		l3.setBounds(100,77,10,10);
		b4.setBounds(110,70,80,30);
		l4.setBounds(190,77,10,10);
		b5.setBounds(200,70,80,30);
		l5.setBounds(280,77,10,10);
		b6.setBounds(290,70,80,30);
		add(l2);
		l1.setBounds(650,0,80,80);
		l2.setBounds(10,100,100,100);
		p1=new Panel();
		p2=new Panel();
		p3=new Panel();
		p4=new Panel();
		p5=new Panel();
		p6=new Panel();
		p7=new Panel();
		p8=new Panel();
		p9=new Panel();
		p10=new Panel();
		p11=new Panel();
		p12=new Panel();
		cg2=new CheckboxGroup();
		cg1=new CheckboxGroup();
		c1=new Checkbox("Total Quality Management                                                    ",false,cg2);
		c2=new Checkbox("INTERNATIONAL BUSINESS                                               ",false,cg2);		
		c3=new Checkbox("Management Accounting and control                                  ",false,cg2);
		c4=new Checkbox("Investment Management                                                       ",false,cg2);
		c5=new Checkbox("International Finance                                                              ",false,cg2);
		c6=new Checkbox("Performance and Compensation Management                ",false,cg2);
		c7=new Checkbox("Organizational Development and Change Management ",false,cg2);
		c8=new Checkbox("Product and Brand Management                                           ",false,cg2);
		c9=new Checkbox("Promotion and Distribution Management                             ",false,cg2);
		c10=new Checkbox("Service Operations Management                                           ",false,cg2);
		c11=new Checkbox("Technology  Management                                                        ",false,cg2);
		p1.add(c1); 
		p1.add(c2);
		p1.add(c3);
		p1.add(c4);
		p1.add(c5);
		p1.add(c6);
		p1.add(c7);
		p1.add(c8);
		p1.add(c9);
		p1.add(c10);
		p1.add(c11);
		add(p1);
		p1.setBounds(30,200,400,350);
		c1.addItemListener(this);
		c2.addItemListener(this);
		c3.addItemListener(this);
		c4.addItemListener(this);
		c5.addItemListener(this);
		c6.addItemListener(this);
		c7.addItemListener(this);
		c8.addItemListener(this);
		c9.addItemListener(this);
		c10.addItemListener(this);
		c11.addItemListener(this);
		
		



		b1=new Button("Done");
		b2=new Button("Next");
		add(b1);
		add(b2);
		b1.setBounds(500,600,50,30);
		b2.setBounds(900,600,50,30);
		b1.addActionListener(this);
		b2.addActionListener(this);
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});

	}
	public void actionPerformed(ActionEvent ae)
	{
	}
	public void itemStateChanged(ItemEvent ie)
	{
		s=((Checkbox)ie.getSource()).getLabel();
		if(s=="Total Quality Management                                                    ")
		{
			c8=new Checkbox("John L. W. Beckford",false,cg2);
			c9=new Checkbox("Dale H. Besterfield",false,cg2);
			p2.add(c8);
			p2.add(c9);
			add(p2);
			p2.setBounds(400,200,400,350);
			this.setVisible(true);
		}
		else if(s=="INTERNATIONAL BUSINESS                                               ")
		{
			c8=new Checkbox("Charles W.K Hill",false,cg2);
			c9=new Checkbox(" Michael R. Czinkota",false,cg2);
			p3.add(c8);
			p3.add(c9);
			add(p3);
			p3.setBounds(400,230,350,350);
			setVisible(true);	
		}
		else if(s=="Management Accounting and control                                  ")
		{
			c8=new Checkbox("Ward. K",false,cg2);
			c9=new Checkbox("Hansen& Mowen",false,cg2);
			p4.add(c8);
			p4.add(c9);
			add(p4);
			p4.setBounds(400,255,400,350);
			setVisible(true);
		}
		else if(s=="Investment Management                                                       ")
		{
			c8=new Checkbox("Donald E. Fischer",false,cg2);
			c9=new Checkbox("V.A.Avadhani",false,cg2);
			p5.add(c8);
			p5.add(c9);
			add(p5);
			p5.setBounds(400,283,350,350);
			setVisible(true);
		}
		else if(s=="International Finance                                                              ")
		{
			c8=new Checkbox("Eun C.S Resnick B.G",false,cg2);
			c9=new Checkbox("Levi M",false,cg2);
			p6.add(c8);
			p6.add(c9);
			add(p6);
			p6.setBounds(400,315,350,350);
			setVisible(true);
		}
		else if(s=="Performance and Compensation Management                ")
		{
			c8=new Checkbox(" Michael Armstrong",false,cg2);
			c9=new Checkbox(" Robert L Cardy",false,cg2);
			p7.add(c8);
			p7.add(c9);
			add(p7);
			p7.setBounds(400,338,350,350);
			setVisible(true);
		}
		else if(s=="Organizational Development and Change Management ")
		{
			c8=new Checkbox("Wendell L.French",false,cg2);
			c9=new Checkbox("Thomas G. Cummings",false,cg2);
			p8.add(c8);
			p8.add(c9);
			add(p8);
			p8.setBounds(400,369,350,350);
			setVisible(true);
		}
		else if(s=="Product and Brand Management                                           ")
		{
			c17=new Checkbox("Pessemier Edgar",false,cg2);
			c18=new Checkbox("Ulrich K T",false,cg2);
			p9.add(c17);
			p9.add(c18);
			add(p9);
			p9.setBounds(400,400,350,350);
			setVisible(true);	
		}
		else if(s=="Promotion and Distribution Management                             ")
		{
			c17=new Checkbox("Shimp",false,cg2);
			c18=new Checkbox("George E Belch",false,cg2);
			p10.add(c17);
			p10.add(c18);
			add(p10);
			p10.setBounds(400,425,350,350);
			setVisible(true);	
		}
		else if(s=="Service Operations Management                                           ")
		{
			c17=new Checkbox("Robert Johnston",false,cg2);
			c18=new Checkbox("James A. Fitzsimmons ",false,cg2);
			p11.add(c17);
			p11.add(c18);
			add(p11);
			p11.setBounds(400,450,350,350);
			setVisible(true);	
		}
		else if(s=="Technology  Management                                                        ")
		{
			c17=new Checkbox("Tarek Khalil",false,cg2);
			c18=new Checkbox("V. K. Narayanan",false,cg2);
			p12.add(c17);
			p12.add(c18);
			add(p12);
			p12.setBounds(400,480,350,350);
			setVisible(true);	
		}
	}
	public void paint(Graphics g)
	{
		
	}
	public static void main(String args[])
	{
		new MBA_2ndYear();
	}
}	
		