import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class Login extends Frame implements ActionListener
{

	TextField tf,tf1;
	Button b,b1;
	Panel p,p1,p2,p3;
	Label tl,l1;
	public static String s,s1,s2,s3="",s4,s5,s6;
	File f1=new File("Username.txt");
	File f2=new File("Password.txt");
	File f3=new File("Rollnumber.txt");
	File f4=new File("Branch.txt");
	File f5=new File("Year.txt");
	

	FileReader fr1;
	FileReader fr2;
	FileReader fr3;
	FileReader fr4;
	FileReader fr5;

	Scanner sc1;
	Scanner sc2;
	Scanner sc3;
	Scanner sc4;
	Scanner sc5;
	boolean bo1,bo2;
	String ll;
	int index=0;
	public Login() throws Exception
	{
		if(!f1.exists())
		{
  			f1.createNewFile();
  			//System.out.println("New file \"myfile.txt\" has been created to the current directory");
		}
		if(!f2.exists())
		{
  			f2.createNewFile();
  			//System.out.println("New file \"myfile.txt\" has been created to the current directory");
		}
		if(!f3.exists())
		{
  			f3.createNewFile();
  			//System.out.println("New file \"myfile.txt\" has been created to the current directory");
		}
		if(!f4.exists())
		{
  			f4.createNewFile();
  			//System.out.println("New file \"myfile.txt\" has been created to the current directory");
		}
		if(!f5.exists())
		{
  			f5.createNewFile();
  			//System.out.println("New file \"myfile.txt\" has been created to the current directory");
		}
		setVisible(true);
		setLayout(null);
		setSize(1500,1500);
		setTitle("LOGIN");
		b=new Button("Login");
		b1=new Button("Signup"); 

		p=new Panel(new FlowLayout(FlowLayout.CENTER));
		p1=new Panel(new GridLayout(3,1));
		p2=new Panel(new FlowLayout(FlowLayout.LEFT));
		p3=new Panel(new FlowLayout(FlowLayout.LEFT));

		tf=new TextField(15);
		tf1=new TextField(15);

		tl=new Label("Username");
		Label tll=new Label("Password");
		Label tl1=new Label("MINI LIBRARY");
		
		tl1.setBounds(600,30,200,30);
		tl1.setFont(new Font("TimesNewRoman",Font.BOLD,20));

		add(tl1);
		p2.add(tl);
		p2.add(tf);
		p1.add(p2);

		p3.add(tll);
		p3.add(tf1);
		p1.add(p3);
		
		p.add(b);
		p.add(b1);
		p1.add(p);
		p1.setBounds(550,200,300,250);
		add(p1);

		
		
		tf1.setEchoChar('*');
		b.addActionListener(this);
		b1.addActionListener(this);

		tf.addActionListener(this);
		tf1.addActionListener(this);
		
		addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent w)
			{
				System.exit(0);
			}
		});
		
	}
	public void actionPerformed(ActionEvent ae)
	{
	try
	{
		fr1=new FileReader(f1);
		fr2=new FileReader(f2);
		fr3=new FileReader(f3);
		fr4=new FileReader(f4);
		fr5=new FileReader(f5);
		sc1=new Scanner(fr1);
		sc2=new Scanner(fr2);
		sc3=new Scanner(fr3);
		sc4=new Scanner(fr4);
		sc5=new Scanner(fr5);
		s=ae.getActionCommand();
		if(s=="Login")
		{
			s1=tf.getText();
			s2=tf1.getText();
				while(sc1.hasNextLine()&&sc2.hasNextLine())
				{
					index++;
					bo1=s1.equals(sc1.nextLine());
					bo2=s2.equals(sc2.nextLine());
					if(bo1&&bo2)
					{
						new Home();
						this.dispose();
						for(int i=1;i<index;i++)
						{
							sc3.nextLine();
							sc4.nextLine();
							sc5.nextLine();
						}
						s4=sc3.nextLine();
						s5=sc4.nextLine();
						s6=sc5.nextLine();

						
						break;
					}
					else if(bo1||bo2)
					{
						l1=new Label("InCorrect UserName or Password");
						add(l1);
						l1.setForeground(Color.RED);
						l1.setBounds(480,430,200,50);
						
						new Login();
						this.dispose();
				
						break;
					}
					
				}
				
				
				l1=new Label("You are not registered go for signup");
				add(l1);
				l1.setForeground(Color.RED);
				l1.setBounds(530,430,200,50);
					
				
					
		}
		else if(s=="Signup")
		{
			try
			{
				new Signup();
				this.dispose();
			}
			catch(IOException v)
			{
			}
		}
	}
	catch(Exception t)
	{}
	}
	public void paint(Graphics g)
	{
		g.drawRect(500,100,350,400);
		g.setColor(Color.RED);
		
	}
	public static void main(String args[]) throws Exception
	{
		new Login();
	}
}	